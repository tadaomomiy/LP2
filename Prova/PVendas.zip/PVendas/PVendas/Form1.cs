﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliarVendas = "";
            int RA = 9; 
            double totalGeral = 0;
            double totalMes = 0;
            double[,] vendas = new double[RA, 4];
            double[] listaTotalMes = new double[RA];

            for (int i = 0; i < RA; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    auxiliarVendas = Interaction.InputBox("Digite o valor de venda do mês: " + (i + 1) + " na semana: " + (x + 1), "Vendas Mês / Semana");
                    if (auxiliarVendas == "")
                        break;
                    if (!double.TryParse(auxiliarVendas, out vendas[i, x]))
                    {
                        MessageBox.Show("O Valor de venda é Inválido!");
                        x -= 1;
                    }
                    else if (vendas[i, x] < 0)
                    {
                        MessageBox.Show("O valor de vendas não pode ser negativo");
                        x -= 1;
                    }
                    else
                    { 
                        lstbxVendas.Items.Add("\nTotal do mês: " + (i + 1) + " Semana: " + (x + 1) + " - R$" + vendas[i, x].ToString("N2"));
                        totalMes += vendas[i, x];
                    }
                }
                listaTotalMes[i] = totalMes;
                lstbxVendas.Items.Add("\n>>Total mês: R$" + listaTotalMes[i].ToString("N2"));
                lstbxVendas.Items.Add("\n-------------");
                totalGeral += listaTotalMes[i];

                if (auxiliarVendas == "")
                    break;
                
                totalMes = 0;
            }
            lstbxVendas.Items.Add("\n>>Total Geral: R$" + totalGeral.ToString("N2"));
        }
    }
}